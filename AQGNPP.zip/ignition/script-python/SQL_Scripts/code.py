ALLOWED_COLUMNS = ['site_name', 'l0_tag','l1_tag','l2_tag','l3_tag','l4_tag', 'computervision', 'sorting']

def write_fish_to_db(tubenum):
	
	path_to_Tube = "[default]/Tubes/Tube" + str(tubenum) 
	path_to_Fish = path_to_Tube  + "/FishOut/ScanData"
	path_to_SortType = path_to_Tube + "/FishOut/SortType"
	path_to_dataTrigger = path_to_Tube + "/NonPLCTriggers/TriggerWriteSQL"
	
	fish_data = system.tag.readBlocking(
		[path_to_Fish]
	)[0].value
	
	sorting_data = system.tag.readBlocking(
		[path_to_SortType]
	)[0].value
	
	split_data = fish_data.split(';')
	
	try: 
		query= """
			INSERT INTO sorting.fish (
			file_id_aris,
		    tag_num,
			filename1,
			filename2,
		    site,
			date,
			time,
			priority,
			prioritygate, 
			speed,
			length,
			circumference,
			weight,
			area,
			condition,
			maturity,
			deformity,
			gate,
			outputlane,
			outputlanereason
			)
		    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		    """
    
	   
		system.db.runPrepUpdate(
		query,
		[
			split_data[0],
		    split_data[1],
			split_data[2],
			split_data[3],
			split_data[4],
			split_data[5],
			split_data[6],
			split_data[7],
			split_data[8],
			split_data[9],
			split_data[10],
			split_data[11],
			split_data[12],
			split_data[13],
			split_data[14],
			split_data[15],
			split_data[16],
			split_data[17],
			str(tubenum),
			sorting_data
		 ],
		"passageportaldb"
		)
		
		system.tag.writeBlocking([path_to_dataTrigger], [False])
		
	
	except Exception, e:
		return e
		


def read_all_db():
	
		data = system.db.runQuery(
	    "SELECT * FROM sorting.fish",
	    "passageportaldb" )
	
		for row in data:
		    print "----- Row -----"
		
		    for columnName in data.getColumnNames():
		        print str(columnName) + " = " + str(row[columnName])

def write_to_status_db(column, value):
	logger = system.util.getLogger("db_utils")
	if column not in ALLOWED_COLUMNS:
		logger.warn("Rejected insert to unknown column: %s" % column)
		return 1
		

	query = "UPDATE status.systemstatus SET %s = ? WHERE id = 1" % column

	try:
		system.db.runPrepUpdate(query, [value], "passageportaldb")
		return 3
	except Exception as e:
		logger.error("Insert to %s failed: %s" % (column, e))
        return 2
	
	

