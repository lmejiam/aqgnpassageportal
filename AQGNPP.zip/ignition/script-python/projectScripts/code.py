def createDataFile6TubeSections(filename):


	f = system.file.fileExists(filename)
	
	if not f:
		system.file.writeFile(str(filename),\
			"StartDate;Lane;ArisID; LaneReq; Species; Length; Circumference;Reserved;Speed;Extra;" +\
			"BypassReason;Time1;Time2;Time3;Time4;Time5;Time6;Time7;Time8;"+\
			"Units;S1;S2;S3;S4;S5;S6;S7;S8;"+\
			"PTubeEntry;P2;P3;P4;PBooster;P6;PExit;BlowerAccel;BlowerBooster" +"\n")
	
	return True 
	
def createDataFile2TubeSections(filename):
	
	f = system.file.fileExists(filename)
	
	if not f:
		system.file.writeFile(str(filename),\
			"StartDate;Lane;ArisID; LaneReq; Species; Length; Circumference;Reserved;Speed;Extra;" +\
			"BypassReason;Time1;Time2;Time3;"+\
			"Units;S1;S2;S3;"+\
			"PTubeEntry;P2;P3;BlowerAccel;" +"\n")
	
	return True 


def addFishData(Dates, TubeNumber, Times, Units, Speeds, Pressures, ScanData, BypassReason, Blowers):
	
	filepath = system.tag.readBlocking(["[default]Platform/Platform/DataPath"])[0].value
	
	f = system.file.fileExists(filepath)
	if not f:
		projectScripts.createDataFile(filename= filepath)
	
	s = str(Dates[0])	+\
	";" + str(TubeNumber)+\
	";" + str(ScanData)+\
	""  + str(BypassReason) +\
	";" + str(Times[0])  +\
	";" + str(Times[1]) 	+\
	";" + str(Times[2]) 	+\
	";" + str(Times[3]) 	+\
	";" + str(Times[4]) 	+\
	";" + str(Times[5]) 	+\
	";" + str(Times[6]) 	+\
	";" + str(Times[7]) 	+\
	";" + str(Units)        +\
	";" + str(Speeds[0]) 	+\
	";" + str(Speeds[1]) 	+\
	";" + str(Speeds[2]) 	+\
	";" + str(Speeds[3]) 	+\
	";" + str(Speeds[4]) 	+\
	";" + str(Speeds[5]) 	+\
	";" + str(Speeds[6]) 	+\
	";" + str(Speeds[7]) 	+\
	";" + str(Pressures[0]) 	+\
	";" + str(Pressures[1]) 	+\
	";" + str(Pressures[2]) 	+\
	";" + str(Pressures[3]) 	+\
	";" + str(Pressures[4]) 	+\
	";" + str(Pressures[5]) 	+\
	";" + str(Pressures[6]) 	+\
	";" + str(Blowers[0]) +\
	";" + str(Blowers[1]) +\
	"\n"
	
	system.file.writeFile(str(filepath), s , True)
		
		
	return True
	
def addFishDataTube2Sensor(Dates, TubeNumber, Times, Units, Speeds, Pressures, ScanData, BypassReason, Blowers):
	
	filepath = system.tag.readBlocking(["[default]Platform/Platform/DataPath"])[0].value
	
	f = system.file.fileExists(filepath)
	if not f:
		projectScripts.createDataFile(filename= filepath)
	
	s = str(Dates[0])	+\
	";" + str(TubeNumber)+\
	";" + str(ScanData)+\
	""  + str(BypassReason) +\
	";" + str(Times[0])  +\
	";" + str(Times[1]) 	+\
	";" + str(Times[2]) 	+\
	";" + str(Units)        +\
	";" + str(Speeds[0]) 	+\
	";" + str(Speeds[1]) 	+\
	";" + str(Speeds[2]) 	+\
	";" + str(Pressures[0]) 	+\
	";" + str(Pressures[1]) 	+\
	";" + str(Pressures[2]) 	+\
	";" + str(Blowers[0]) +\
	"\n"
	
	system.file.writeFile(str(filepath), s , True)
		
		
	return True
	
	
	
	
def addSortingFishData(Dates, ExitNum, Times, ScanData, BypassReason):
	
	filepath = system.tag.readBlocking(["[default]Platform/Platform/DataPath"])[0].value
	
	f = system.file.fileExists(filepath)
	if not f:
		projectScripts.createDataFile(filename= filepath)
	
	s = str(Dates[0])	+\
	";" + str(ExitNum)+\
	";" + str(ScanData)+\
	""  + str(BypassReason) +\
	";" + str(Times[0])  +\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " "        +\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " 	+\
	";" + " " +\
	";" + " " +\
	"\n"
	
	system.file.writeFile(str(filepath), s , True)
	
		
	return True
	
def stopOverride():
	
	results= system.tag.browse("[default]", {"recursive": True, "name": "Override"})
	substring = "_types_"
	paths = []
	values = []
	
	for i in results.getResults():
		
		stringPath = str(i['fullPath'])
		
		if substring not in stringPath:
			paths.append(stringPath)
			values.append(False)
			
			
	
	system.tag.writeBlocking(paths, values)

	
	return void
	
def clearAlarms():
	
	
	results = system.tag.browse("[default]", {"recursive": True, "name": "*Fault*"})	
	substring = "_types_"
	paths = []
	values = []
	
	for i in results.getResults():
		
		stringPath = str(i['fullPath'])
		
		if substring not in stringPath:
			paths.append(stringPath)
			values.append(False)
			
			
	system.tag.writeBlocking(paths, values)
	
	
	results2 = system.tag.browse("[default]", {"recursive": True, "name": "*FaultReset*"})	
	paths2 = []
	values2 = []
	
	for i in results2.getResults():
		
		stringPath = str(i['fullPath'])
		
		if substring not in stringPath:
			paths2.append(stringPath)
			values2.append(True)
			
			
	system.tag.writeBlocking(paths2, values2)
	
	return void
	
def update_tags(path):
	
	tagPath = "[default]"

	result = system.tag.importTags(path, tagpath, "o")  # "m" = merge
	
	return void
	