def updateTags():
	logger = system.util.getLogger("TagImport")
	
	try:
		
		filePath = "/WhooshhProjectFiles/ignitionpassageportal/tags.json"
		basePath = "[default]"
	 
		system.tag.importTags(filePath,basePath, "o")
		logger.info("Import result: " + str(result))
		return "Good"
		
	except Exception as e:
		
		logger.error("Import failed: " + str(e))
		return "error" + str(e)
		
