import base64
import os

def newImageLoad(name):
	try:
		
		path = os.path.join(r"C:\Users\Leonardo Mejia\Desktop\Ignition Data",name)
		with open(path, "rb") as f:
			encoded = base64.b64encode(f.read()).decode("utf-8")
		
		imageSource = "data:image/jpeg;base64," + encoded
	
		return imageSource
	
	except Exception as e:
		return ""
	

