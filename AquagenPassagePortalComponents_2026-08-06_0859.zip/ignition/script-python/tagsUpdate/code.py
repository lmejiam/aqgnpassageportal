def updateTags():
	
	
	try:
		
		filePath = "WhooshhProjectFiles/ignitionpassageportal/tags.json"
		basePath = "[default]"
	 
		system.tag.importTags(filePath,basePath, "i")
		
		return "Good"
		
	except Exception as e:
		return "error"
		
